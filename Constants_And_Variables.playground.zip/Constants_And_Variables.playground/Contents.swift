//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

// three basic variables
var newInt = 0;
var newFloat = 0.0;
var newDouble = 0.0;

// three basic constants
let constInt = 0;
let constFloat = 0.0;
let constDouble = 0.0;

// three type explicit constants
let constString: String;
let newConstFloat: Float;
let newConstDouble: Double;

// testing const ability to change (they won't)
let testInt = 42;
testInt = 84;
// as expected the constant will not change

// a type explicit constant float w/ initial variable of 4
let testConstFloat: Float = 4;
// As expected there is no problem setting an explicit type and then assigning a value to a constant. 
// *Spock eyebrow raise* Logical.


